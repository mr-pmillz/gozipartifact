<?php
/**
 * Human Element Inc.
 *
 * @package HumanElement_EmailLogoFix
 * @copyright Copyright (c) 2017 Human Element Inc. (https://www.human-element.com)
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'HumanElement_EmailLogoFix',
    __DIR__
);