# module-email-logo-fix
Human Element Magento 2 Email Logo Fix

assuming your project has access to the human element composer repo

to install:

```
composer require human-element/module-email-logo-fix
```

to update:

```
composer update human-element/module-email-logo-fix
```
